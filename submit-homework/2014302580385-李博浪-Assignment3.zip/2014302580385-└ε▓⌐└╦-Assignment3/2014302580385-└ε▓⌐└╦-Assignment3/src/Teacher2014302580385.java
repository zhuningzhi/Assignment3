
public class Teacher2014302580385
{
	private String name;
	private String phone;
	private String email;
	private String introduction;
	private String research;
	
	public void setName(String name){this.name=name;}
	public void setPhone(String phone){this.phone=phone;}
	public void setEmail(String email){this.email=email;}
	public void setIntroduction(String introduction){this.introduction=introduction;}
	public void setResearch(String research){this.research=research;}
	
	public String getName(){return name;}
	public String getPhone(){return phone;}
	public String getEmail(){return email;}
	public String getIntroduction(){return introduction;}
	public String getResearch(){return research;}
	public Teacher2014302580385()
	{
	
	}	
	

}
