import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class TeacherList2014302580385
{
	private String url;
	private String index;
	private File input;
	private String[] teacherList;
	private String prefixURL;
	public final static int teacherNumber=7;
	public static int getTeacherNumber(){return teacherNumber;};
	public TeacherList2014302580385()
	{
		index="all.html";
		input=new File(index);
		url="http://web.xidian.edu.cn/showcollege.php?col_num=8";				
		prefixURL="http://web.xidian.edu.cn";
	}//end Teacher()
	
	public String[] getTeacherList()
	{
		return teacherList;
	}
	
	//��ý�ʦ�б��и�����ʦ�ĸ�����ҳ��url��ַ
	public void FindTeacherList() throws IOException
	{
		HttpRequest abc=new HttpRequest(url,"GET");
		abc.receive(input);
		teacherList=new String[teacherNumber];
		Document doc=Jsoup.parse(input,"UTF-8",prefixURL);
		Elements links=doc.select("a[href]");
		Pattern teacherPattern=Pattern.compile("/[a-z]+");
		
		int count=0;
		for(Element link:links)
		{
			Matcher teacherMatcher=teacherPattern.matcher(link.attr("href"));
			if(teacherMatcher.matches()==true)
			{
				if(count<teacherList.length)
				{
					if(link.attr("href").equals("/pwei")==false&&link.attr("href").equals("/ylxia")==false&&link.attr("href").equals("/yangxd")==false&&link.attr("href").equals("/whzhu")==false&&link.attr("href").equals("/chlbai")==false&&link.attr("href").equals("/ljw")==false&&link.attr("href").equals("/liujin")==false&&link.attr("href").equals("/wcl")==false&&link.attr("href").equals("/wuchengli")==false&&link.attr("href").equals("/hxyu")==false&&link.attr("href").equals("/zouhe")==false)
					{
						teacherList[count]=prefixURL+link.attr("href");  //ljw��liujin,��sbshi���޵绰����wcl��wuchengli����ylxia������̫�ࡱ����yangxd��mzhzhang���޵绰����ȡ���hxyu��zouhe,link.attr("href")!="/ljw"&&link.attr("href")!="/liujin"&&link.attr("href")!="/sbshi"&&link.attr("href")!="/wcl"&&link.attr("href")!="/wuchengli"&&link.attr("href")!="/ylxia"&&link.attr("href")!="/yangxd"&&link.attr("href")!="/mzhzhang"&&link.attr("href")!="/hxyu"&&link.attr("href")!="/zouhe"
						count++;
					}
				}
			
						
			}
					
		}
	}//end FindTeacherList
	
	//����ʦ������ҳץȡ������������File�����Ͳ�����
	public File getHTML(String url)
	{
		String fileName=url.substring(url.length()-5, url.length())+".html";
		File teacherHTML=new File(fileName);
		HttpRequest abc=new HttpRequest(url,"GET");
		abc.receive(teacherHTML);
		return teacherHTML;
	}
	
	//������ҳ����ȡ��ʦ�ĸ�����Ϣ
	public void parseHTML(File teacherHTML,Teacher2014302580385 teacher) throws IOException
	{
		Document doc=Jsoup.parse(teacherHTML,"UTF-8",prefixURL);
		
		//��ȡ����
		Element nameDiv=doc.getElementById("n0"); 
		Elements nameElements=nameDiv.getElementsByTag("p");
		Element nameElement=nameElements.first().nextElementSibling();
		teacher.setName(nameElement.text().substring(0, 3));
		
		//��ȡ�绰
		Element phoneDiv=doc.getElementById("n3");
		Elements phoneElements=phoneDiv.getElementsByTag("p");
		Pattern phonePattern=Pattern.compile(".*[0-9]{8}.*");
		for(Element temp:phoneElements)
		{
			Matcher phoneMatcher=phonePattern.matcher(temp.text());
			if(phoneMatcher.matches())
			{
				teacher.setPhone(temp.text().substring(temp.text().length()-8));
			}
		}
		
		if(teacher.getPhone()==null)
		{
			teacher.setPhone("null");
		}//��������Ϊ�յ����
		//��ȡ����
		Element emailDiv=doc.getElementById("n3");
		Elements emailElements=emailDiv.getElementsByTag("p");
		Pattern emailPattern=Pattern.compile(".*@.*");
		for(Element temp:emailElements)
		{
			Matcher emailMatcher=emailPattern.matcher(temp.text());
			if(emailMatcher.matches())
			{
				
				teacher.setEmail(temp.text().substring(5, temp.text().length()));
			}
		}
		
		if(teacher.getEmail()==null)
		{
			teacher.setEmail("null");
		}//��������Ϊ�յ����
		//��ȡ����
		Element introductionDiv=doc.getElementById("n2");
		Elements introductionElements=introductionDiv.getElementsByTag("p");
		String tempIntroduction="";
		for(Element temp:introductionElements)
		{
			if(temp.text().equals("&nbsp;")==false)
			{
				if(temp.text().substring(0,1).equals("&nbsp;")==false&&temp.text().substring(temp.text().length()-1,temp.text().length()).equals("&nbsp;")==false)
				{
					tempIntroduction+=temp.text();
				}else if(temp.text().substring(0,1).equals("&nbsp;")==true&&temp.text().substring(temp.text().length()-1,temp.text().length()).equals("&nbsp;")==false)
				{
					tempIntroduction+=temp.text().substring(1,temp.text().length());
				}else if(temp.text().substring(0,1).equals("&nbsp;")==false&&temp.text().substring(temp.text().length()-1,temp.text().length()).equals("&nbsp;")==true)
				{
					tempIntroduction+=temp.text().substring(0,temp.text().length()-1);
				}else if(temp.text().substring(0,1).equals("&nbsp;")==true&&temp.text().substring(temp.text().length()-1,temp.text().length()).equals("&nbsp;")==true)
				{
					tempIntroduction+=temp.text().substring(1,temp.text().length()-1);
				}
			}
		}
		teacher.setIntroduction(tempIntroduction);
		
		if(teacher.getIntroduction()==null)
		{
			teacher.setIntroduction("null");
		}//��������Ϊ�յ����
		//��ȡ�о�����
		
		Element researchDiv=doc.getElementById("n1");
		Elements researchElements=researchDiv.getElementsByTag("p");
		String tempResearch="";
		for(Element temp:researchElements)
		{
			tempResearch+=temp.text();
		}
		teacher.setResearch(tempResearch);
		
		if(teacher.getResearch()==null)
		{
			teacher.setResearch("null");
		}//��������Ϊ�յ����
	}
}
