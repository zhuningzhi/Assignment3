import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;


public class Main2014302580385
{

	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException, InterruptedException
	{
		long singleStartTime = System.currentTimeMillis();//��ȡ���߳̿�ʼʱ��
		//���̲߳���
		
		// ץȡ��ҳ����ý�ʦ������ҳ���б�
		TeacherList2014302580385 teacher=new TeacherList2014302580385();
		teacher.FindTeacherList();
		Teacher2014302580385[] teachers=new Teacher2014302580385[TeacherList2014302580385.teacherNumber];
		for(int i=0;i<TeacherList2014302580385.teacherNumber;i++)
		{
			teachers[i]=new Teacher2014302580385();
			teacher.parseHTML(teacher.getHTML(teacher.getTeacherList()[i]), teachers[i]);
			//System.out.println(teachers[i].getName());
		}
		
		
		
		//���̲߳���
		Long mutiStartTime=System.currentTimeMillis(); //��ȡ���߳̿�ʼʱ��
	
		TeacherList2014302580385 mutiTeacherList=new TeacherList2014302580385();
		mutiTeacherList.FindTeacherList();
		Teacher2014302580385[] mutiTeacher=new Teacher2014302580385[TeacherList2014302580385.teacherNumber];
		
		
		Buffer2014302580385 buffer=new Buffer2014302580385();
		Thread[] getThread=new Thread[TeacherList2014302580385.teacherNumber];
		
		//�ö��߳�ץȡ��ҳ��ÿ����ҳ����һ���߳�
		for(int i=0;i<TeacherList2014302580385.teacherNumber;i++)
		{
			final int number=i;
			getThread[i]=new Thread(new Runnable()
			{
			
				public void run()
				{			
					mutiTeacher[number]=new Teacher2014302580385();
					try
					{
						buffer.setFile(mutiTeacherList.getHTML(mutiTeacherList.getTeacherList()[number]));
						
					} catch (InterruptedException e)
					{
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
				}
			});
		}
		
		//������ҳ
		Thread parseThread=new Thread(new Runnable()
		{
			public void run()
			{
				for(int i=0;i<TeacherList2014302580385.teacherNumber;i++)
				{
					try
					{
						while(buffer.getFile(i)==null)
						{
							Thread.sleep(10);
						}//�����������file��δд��buffer��			
						mutiTeacherList.parseHTML(buffer.getFile(i),mutiTeacher[i]);
						
					} catch (IOException | InterruptedException e)
					{
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
				}
			}
		});
		
		for(int i=0;i<TeacherList2014302580385.teacherNumber;i++)
		{
			getThread[i].start();
		}
		parseThread.start();
		for(int i=0;i<TeacherList2014302580385.teacherNumber;i++)
		{
			getThread[i].join();
		}
		
		parseThread.join();
		
		long endTime=System.currentTimeMillis();
		long singleTime=mutiStartTime-singleStartTime;
		long mutiTime=endTime-mutiStartTime;
		System.out.println("���߳�ִ��ʱ�䣺"+singleTime);
		System.out.println("���߳�ִ��ʱ�䣺"+mutiTime);		
		
		//д�����ݿ�
		String sql;
		Database2014302580385 database=new Database2014302580385();	
		Connection conn=database.getConnection();
		PreparedStatement ps=null;
		for(int i=0;i<TeacherList2014302580385.teacherNumber;i++)
		{		
			sql="insert into teacher(name,phone,email,introduction,research) values('"+mutiTeacher[i].getName()+"','"+mutiTeacher[i].getPhone()+"','"+mutiTeacher[i].getEmail()+"','"+mutiTeacher[i].getIntroduction()+"','"+mutiTeacher[i].getResearch()+"');";				
			ps=conn.prepareStatement(sql);
			ps.executeUpdate(sql);			
		}
		ps.close();
		conn.close();
		System.out.println("�ɹ�����");
	
	}

}

