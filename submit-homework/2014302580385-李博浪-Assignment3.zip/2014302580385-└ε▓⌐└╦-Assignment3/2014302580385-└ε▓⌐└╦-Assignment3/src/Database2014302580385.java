import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Database2014302580385
{
	public String url ;//127.0.0.1
	public String user; 
	public String psw ; 
	public Database2014302580385()
	{
		url ="jdbc:mysql://127.0.0.1:3306/new_schema";//localhost
		user = "root"; 
		psw = "lbl730911"; 
	}
	public Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn=DriverManager.getConnection(url,user,psw);
		 System.out.println("ע�������ɹ�");
	        return conn;
	}
}

