package Assignment3;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

public class crawl2014302580175 {

//��ȥ����ʦ
	private String url="http://staff.whu.edu.cn";
	private String[] urls;
	
	public crawl2014302580175(){
		try 
		{
			urls=getURL(url);
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


	
// ��ȡ���еĽ�ʦurl
	 
	public String [] getURL(String url) throws IOException{
		Document document=Jsoup.connect(url).get();
		String [] teacherurls=new String[100];
		int i=0;
		Elements elements=document.select("div.details > p > a[href]");
		for(Node node:elements)
		{
			teacherurls[i++]=node.attr("href");
		}
		return teacherurls;
	}
	
	
	
//��ȡ������ʦ����Ϣ

	public teacherinformation2014302580175 getTeacher(int index) throws IOException{
		String url=this.url+"/"+urls[index];
		Document document=Jsoup.connect(url).get();

//��ȡ������ͷ�Σ��о�������ϵ�绰��email
		Elements briefInformation=document.select("div.col-xs-7");
		String [] teacherInformation=new String[5];
		int i=0;
		String regex=">(.+)<";	
		Pattern pattern=Pattern.compile(regex);
	//��Elements��ɸѡ����������Ϣ���������teacherInformation������
		for(Element element:briefInformation){
			Matcher matcher=pattern.matcher(element.toString());
			while(matcher.find()){
				String strs[]=matcher.group().replaceAll(regex,"$1").split("<br>");
			//ȥ��������Ϣ
			for(String str:strs){
				String regex2="(.*)(�о�����[^<]+)<.*";
				if(str.matches(regex2))
				{str=str.replaceAll(regex2,"$1");}
				str=str.trim();
				teacherInformation[i++]=str;
				}
			}
		}
		return new teacherinformation2014302580175(teacherInformation);
	}
	
}

