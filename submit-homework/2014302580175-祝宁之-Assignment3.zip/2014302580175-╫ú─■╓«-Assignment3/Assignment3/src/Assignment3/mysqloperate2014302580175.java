package Assignment3;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Connection;

public class mysqloperate2014302580175 {
//����mysql���ݿ�
	private String url="jdbc:mysql://localhost:3306/new_schema?"
			+ "user=root&password=mysql175";
	public Connection getConnection(){
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();}
		try {
			connection=(Connection) DriverManager.getConnection(url);} 
		catch (SQLException e) {
			e.printStackTrace();}
		return connection;
	}

//���ݿ����
	public void runUpdate(teacherinformation2014302580175 teacher){
		Connection connection=null;
		Statement statement=null;
		try {
			connection=getConnection();
			statement=connection.createStatement();} 
		catch (SQLException e) {
			e.printStackTrace();}
		try {
          //teacherinformation������WorkBench�н���
			String sql="insert into teacherinformation(name,title,direction,phone,email) "
			+ "values('"+teacher.getName()+"','"+teacher.getTitle()+"','"+teacher.getDirection()
			+"','"+teacher.getPhone()+"','"+teacher.getEmail()+"')";
			statement.executeUpdate(sql);} 
		catch (SQLException e) {
			e.printStackTrace();}
		finally{
			try {
				statement.close();
				connection.close();} 
			catch (SQLException e) {
				e.printStackTrace();}
		}
	}
}


