package Assignment3;

import java.io.IOException;

public class read2014302580175 implements Runnable {
private buffer2014302580175 buffer;
	
	public read2014302580175(buffer2014302580175 buffer){
		this.buffer=buffer;}
	
	public void run(){
		for(int i=0;i<100;i++){
			try {
				buffer.wrieInBufferArray(i);} 
			catch (IOException e) {
				e.printStackTrace();}
		}
	}
}


