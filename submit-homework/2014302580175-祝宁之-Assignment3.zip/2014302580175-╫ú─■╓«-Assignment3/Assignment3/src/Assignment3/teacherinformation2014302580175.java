package Assignment3;

public class teacherinformation2014302580175 {
	private String name;
	private String title;
	private String direction;
	private String phone;
	private String email;

//���캯����ʼ��
	public teacherinformation2014302580175(String [] teacherInfomation)
	{
		name=teacherInfomation[0];
		title=teacherInfomation[1];
		direction=teacherInfomation[2];
		phone=teacherInfomation[3];
		email=teacherInfomation[4];
	}
	
//��ȡ����
	public String getName(){return name;}
	
//��ȡͷ��
	public String getTitle(){return title;}
	
//��ȡ�о�����
	public String getDirection(){return direction;}
	
//��ȡ�绰
	public String getPhone(){return phone;}
	
//��ȡemail
	public String getEmail(){return email;}

}
