package Assignment3;

import java.io.IOException;


public class main2014302580175 {
//������
	public static void main(String[] args) throws IOException
	{
		
		singleThread();
		multiplyThread();
	}
	

// ���߳���ȡ
	public static void singleThread()
	{
		long begin=System.currentTimeMillis();
		buffer2014302580175 buffer=new buffer2014302580175();
		buffer.singleWrieInBufferArray();
		buffer.singleWriteInSql();
		long end=System.currentTimeMillis();
		System.out.println("SingleThread Run:"+(end-begin));
	
	}

	
//���߳���ȡ
	public static void multiplyThread()
	{
		buffer2014302580175 buffer=new buffer2014302580175();
		Thread threadone,threadtwo;
		threadone=new Thread(new read2014302580175(buffer));
		threadtwo=new Thread(new write2014302580175(buffer));
		threadone.start();
		threadtwo.start();
		
	}
	
}


