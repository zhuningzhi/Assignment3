package Assignment3;

public class write2014302580175 implements Runnable {
	private buffer2014302580175 buffer;
	private mysqloperate2014302580175 database;
	
	public write2014302580175(buffer2014302580175 buffer){
		this.buffer=buffer;
		database=new mysqloperate2014302580175();
	}

	public void run() {
		long begin=System.currentTimeMillis();
		for(int i=0;i<100;i++){
			database.runUpdate(buffer.writeInSql());
		}
		long end=System.currentTimeMillis();
		//������̵߳�������ʱ��
		System.out.println("MultiplyThread Runtime:"+(end-begin));
	}

}
